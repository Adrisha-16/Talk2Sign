# Talk2Sign 
A cutting-edge, AI-powered solution designed to break down communication barriers between the hearing and deaf communities.
